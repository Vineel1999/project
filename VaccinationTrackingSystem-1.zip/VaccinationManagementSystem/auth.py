import csv

auth_file = "database/users.csv"  # File to store user credentials (admin/public roles)

def initialize_users():
    """Initialize users file with some sample data if not exists."""
    try:
        with open(auth_file, "x", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Username", "Password", "Role"])  # Define roles: admin or user
            writer.writerow(["admin", "adminpass", "admin"])
            writer.writerow(["user", "userpass", "user"])
    except FileExistsError:
        pass

def login(username, password):
    """
    Authenticate user by verifying credentials from users.csv.
    """
    try:
        with open(auth_file, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["Username"] == username and row["Password"] == password:
                    return row["Role"]  # Return the role (e.g., 'admin' or 'user')
    except FileNotFoundError:
        return None  # If file does not exist, return None
    return None
