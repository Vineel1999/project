import csv
import os

def get_next_id():
    """
    Get the next sequential ID from the vaccination.csv file.
    If the file is empty, start with ID 1001.
    """
    vaccination_file = "database/vaccination.csv"
    os.makedirs(os.path.dirname(vaccination_file), exist_ok=True)
    try:
        with open(vaccination_file, "r", newline="") as f:
            reader = csv.reader(f)
            data = list(reader)
            if len(data) > 1:  # Check if there are rows after the header
                last_row = data[-1]
                last_id = int(last_row[5])  # Assuming ID is the 6th column
                return last_id + 1
    except FileNotFoundError:
        pass  # If file does not exist, start with the first ID
    return 1001

def add_vaccination_registration(details):
    """
    Add vaccination registration details to vaccination.csv.
    Automatically assigns a sequential ID.
    `details` should be a list containing: [name, dob, phone, email, gender, vaccine]
    """
    vaccination_file = "database/vaccination.csv"
    os.makedirs(os.path.dirname(vaccination_file), exist_ok=True)
    
    # Get the next ID
    next_id = get_next_id()
    
    # Append the ID to the details
    details.insert(5, next_id)  # Insert the ID as the 6th column

    # Write to the CSV file
    with open(vaccination_file, "a", newline="") as f:
        writer = csv.writer(f)
        # Write the header if the file is empty
        if os.stat(vaccination_file).st_size == 0:
            writer.writerow(["Name", "DOB", "Phone", "Email", "Gender", "ID", "Vaccine"])
        writer.writerow(details)

def add_user_registration(details):
    """
    Add user registration details to users.csv, ensuring no duplicate usernames.
    `details` should be a list containing: [username, password, role]
    """
    user_file = "database/users.csv"
    os.makedirs(os.path.dirname(user_file), exist_ok=True)
    
    # Check for duplicate username
    try:
        with open(user_file, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["Username"] == details[0]:  # Check if username exists
                    raise ValueError("Username already exists")
    except FileNotFoundError:
        pass  # If the file doesn't exist, proceed to write

    # Add new user
    with open(user_file, "a", newline="") as f:
        writer = csv.writer(f)
        print(f"Writing to CSV: {details}")  # Debugging line
        writer.writerow(details)