import pandas as pd
import os

appointments_file = "database/appointments.csv"
users_file = "database/users.csv"

def initialize_appointments_file():
    """
    Ensure that the appointments.csv file exists and has the correct headers.
    """
    if not os.path.exists(appointments_file):
        os.makedirs(os.path.dirname(appointments_file), exist_ok=True)
        # Create a new file with the correct headers
        pd.DataFrame(columns=["Username", "Vaccine", "Date"]).to_csv(appointments_file, index=False)

def schedule_appointment(username, vaccine_name, date):
    """
    Schedule an appointment using the Username.
    Ensure the user exists and no duplicate appointments are made for the same user and date.
    """
    initialize_appointments_file()

    # Validate that the username exists in users.csv
    try:
        users_df = pd.read_csv(users_file)
        if username not in users_df["Username"].values:
            raise ValueError("User does not exist. Please register first.")
    except FileNotFoundError:
        raise ValueError("Users file not found. Please register users first.")

    # Check for existing appointments
    try:
        appointments_df = pd.read_csv(appointments_file)
    except FileNotFoundError:
        # If the appointments file doesn't exist, create an empty DataFrame
        appointments_df = pd.DataFrame(columns=["Username", "Vaccine", "Date"])

    if ((appointments_df["Username"] == username) & (appointments_df["Date"] == date)).any():
        raise ValueError("Appointment already exists for this user on this date!")

    # Add new appointment using concat
    new_appointment = pd.DataFrame([{"Username": username, "Vaccine": vaccine_name, "Date": date}])
    appointments_df = pd.concat([appointments_df, new_appointment], ignore_index=True)

    # Save the updated appointments DataFrame to the file
    appointments_df.to_csv(appointments_file, index=False)